import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Calculator, TrendingUp, TrendingDown, Info, Activity } from 'lucide-react';

interface OptionInputs {
  spotPrice: number;
  strikePrice: number;
  timeToMaturity: number;
  riskFreeRate: number;
  volatility: number;
  optionType: 'call' | 'put';
}

interface Greeks {
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
}

const BlackScholesCalculator = () => {
  const [inputs, setInputs] = useState<OptionInputs>({
    spotPrice: 100,
    strikePrice: 100,
    timeToMaturity: 1,
    riskFreeRate: 0.05,
    volatility: 0.2,
    optionType: 'call'
  });

  const [optionPrice, setOptionPrice] = useState<number>(0);
  const [greeks, setGreeks] = useState<Greeks>({
    delta: 0,
    gamma: 0,
    theta: 0,
    vega: 0,
    rho: 0
  });

  // Normal cumulative distribution function
  const normCDF = (x: number): number => {
    return (1 + erf(x / Math.sqrt(2))) / 2;
  };

  // Error function approximation
  const erf = (x: number): number => {
    const a1 = 0.254829592;
    const a2 = -0.284496736;
    const a3 = 1.421413741;
    const a4 = -1.453152027;
    const a5 = 1.061405429;
    const p = 0.3275911;

    const sign = x >= 0 ? 1 : -1;
    x = Math.abs(x);

    const t = 1.0 / (1.0 + p * x);
    const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);

    return sign * y;
  };

  // Normal probability density function
  const normPDF = (x: number): number => {
    return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
  };

  // Black-Scholes pricing function
  const calculateOptionPrice = (params: OptionInputs): number => {
    const { spotPrice: S, strikePrice: K, timeToMaturity: T, riskFreeRate: r, volatility: sigma, optionType } = params;
    
    const d1 = (Math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
    const d2 = d1 - sigma * Math.sqrt(T);

    if (optionType === 'call') {
      return S * normCDF(d1) - K * Math.exp(-r * T) * normCDF(d2);
    } else {
      return K * Math.exp(-r * T) * normCDF(-d2) - S * normCDF(-d1);
    }
  };

  // Calculate Greeks
  const calculateGreeks = (params: OptionInputs): Greeks => {
    const { spotPrice: S, strikePrice: K, timeToMaturity: T, riskFreeRate: r, volatility: sigma, optionType } = params;
    
    const d1 = (Math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
    const d2 = d1 - sigma * Math.sqrt(T);

    const delta = optionType === 'call' ? normCDF(d1) : -normCDF(-d1);
    const gamma = normPDF(d1) / (S * sigma * Math.sqrt(T));
    const theta = optionType === 'call' 
      ? -(S * normPDF(d1) * sigma) / (2 * Math.sqrt(T)) - r * K * Math.exp(-r * T) * normCDF(d2)
      : -(S * normPDF(d1) * sigma) / (2 * Math.sqrt(T)) + r * K * Math.exp(-r * T) * normCDF(-d2);
    const vega = S * normPDF(d1) * Math.sqrt(T);
    const rho = optionType === 'call'
      ? K * T * Math.exp(-r * T) * normCDF(d2)
      : -K * T * Math.exp(-r * T) * normCDF(-d2);

    return { delta, gamma, theta, vega, rho };
  };

  // Recalculate when inputs change
  useEffect(() => {
    const price = calculateOptionPrice(inputs);
    const calculatedGreeks = calculateGreeks(inputs);
    setOptionPrice(price);
    setGreeks(calculatedGreeks);
  }, [inputs]);

  const updateInput = (field: keyof OptionInputs, value: number | string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const formatNumber = (num: number, decimals: number = 4): string => {
    return num.toFixed(decimals);
  };

  const getGreekColor = (value: number, type: string): string => {
    if (type === 'delta') {
      return value > 0 ? 'text-financial-success' : 'text-financial-danger';
    }
    if (type === 'theta') {
      return value < 0 ? 'text-financial-danger' : 'text-financial-success';
    }
    return 'text-foreground';
  };

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-[image:var(--gradient-background)] p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
              <div className="p-3 bg-[image:var(--gradient-primary)] rounded-xl shadow-[var(--shadow-glow)]">
                <Calculator className="h-8 w-8 text-primary-foreground" />
              </div>
              <h1 className="text-4xl font-bold bg-[image:var(--gradient-primary)] bg-clip-text text-transparent">
                Black-Scholes Option Pricing
              </h1>
            </div>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Calculate option prices and Greeks using the Black-Scholes model with real-time updates
            </p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Input Parameters */}
            <div className="xl:col-span-2 space-y-6">
              <Card className="bg-[image:var(--gradient-card)] border-border shadow-[var(--shadow-elevation)]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-primary" />
                    Option Parameters
                  </CardTitle>
                  <CardDescription>
                    Enter the parameters for your option pricing calculation
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="spotPrice">Spot Price (S)</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Current price of the underlying asset</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <Input
                      id="spotPrice"
                      type="number"
                      value={inputs.spotPrice}
                      onChange={(e) => updateInput('spotPrice', parseFloat(e.target.value) || 0)}
                      className="bg-input border-border"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="strikePrice">Strike Price (K)</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Price at which the option can be exercised</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <Input
                      id="strikePrice"
                      type="number"
                      value={inputs.strikePrice}
                      onChange={(e) => updateInput('strikePrice', parseFloat(e.target.value) || 0)}
                      className="bg-input border-border"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="timeToMaturity">Time to Maturity (T)</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Time until expiration in years</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <Input
                      id="timeToMaturity"
                      type="number"
                      step="0.01"
                      value={inputs.timeToMaturity}
                      onChange={(e) => updateInput('timeToMaturity', parseFloat(e.target.value) || 0)}
                      className="bg-input border-border"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="riskFreeRate">Risk-Free Rate (r)</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Risk-free interest rate (e.g., 0.05 for 5%)</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <Input
                      id="riskFreeRate"
                      type="number"
                      step="0.001"
                      value={inputs.riskFreeRate}
                      onChange={(e) => updateInput('riskFreeRate', parseFloat(e.target.value) || 0)}
                      className="bg-input border-border"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="volatility">Volatility (σ)</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Annualized volatility (e.g., 0.2 for 20%)</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <Input
                      id="volatility"
                      type="number"
                      step="0.01"
                      value={inputs.volatility}
                      onChange={(e) => updateInput('volatility', parseFloat(e.target.value) || 0)}
                      className="bg-input border-border"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="optionType">Option Type</Label>
                    <Select 
                      value={inputs.optionType} 
                      onValueChange={(value: 'call' | 'put') => updateInput('optionType', value)}
                    >
                      <SelectTrigger className="bg-input border-border">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="call">Call Option</SelectItem>
                        <SelectItem value="put">Put Option</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Results */}
            <div className="space-y-6">
              {/* Option Price */}
              <Card className="bg-[image:var(--gradient-card)] border-border shadow-[var(--shadow-elevation)]">
                <CardHeader className="text-center">
                  <CardTitle className="flex items-center justify-center gap-2">
                    {inputs.optionType === 'call' ? (
                      <TrendingUp className="h-5 w-5 text-financial-success" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-financial-danger" />
                    )}
                    Option Price
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-4xl font-bold text-primary mb-2">
                    ${formatNumber(optionPrice, 2)}
                  </div>
                  <Badge variant="secondary" className="text-sm">
                    {inputs.optionType.toUpperCase()} Option
                  </Badge>
                </CardContent>
              </Card>

              {/* Greeks */}
              <Card className="bg-[image:var(--gradient-card)] border-border shadow-[var(--shadow-elevation)]">
                <CardHeader>
                  <CardTitle>Option Greeks</CardTitle>
                  <CardDescription>Risk sensitivities</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Delta</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Price sensitivity to underlying asset</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className={`text-lg font-semibold ${getGreekColor(greeks.delta, 'delta')}`}>
                        {formatNumber(greeks.delta)}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Gamma</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Rate of change of delta</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className="text-lg font-semibold text-foreground">
                        {formatNumber(greeks.gamma)}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Theta</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Time decay sensitivity</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className={`text-lg font-semibold ${getGreekColor(greeks.theta, 'theta')}`}>
                        {formatNumber(greeks.theta)}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Vega</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Volatility sensitivity</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className="text-lg font-semibold text-foreground">
                        {formatNumber(greeks.vega)}
                      </div>
                    </div>

                    <div className="space-y-1 col-span-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Rho</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Interest rate sensitivity</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className="text-lg font-semibold text-foreground">
                        {formatNumber(greeks.rho)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default BlackScholesCalculator;