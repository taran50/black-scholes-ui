import BlackScholesCalculator from '@/components/BlackScholesCalculator';

const Index = () => {
  return <BlackScholesCalculator />;
};

export default Index;
